from distutils.core import setup

setup(
    name='AnotherPyplotLatexifier',
    version='1.0dev',
    packages=['Latexify'],
    license='None',
    long_description=open('README.md').read(),
)