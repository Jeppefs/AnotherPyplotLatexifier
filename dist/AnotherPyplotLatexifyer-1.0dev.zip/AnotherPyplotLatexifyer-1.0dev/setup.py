from distutils.core import setup

setup(
    name='AnotherPyplotLatexifyer',
    version='1.0dev',
    packages=['AnotherPyplotLatexifyer',],
    license='None',
    long_description=open('README.md').read(),
)